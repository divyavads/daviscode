#include <string>
#include <iostream>
#include "Airplane.h"

using namespace std;

Airplane::Airplane(int n): maxContainers(n)
{
}

int Airplane::maxLoad() const
{
    return maxContainers;
}

int Airplane::currentLoad() const
{
    return numContainers;
}

bool Airplane::addContainers(int n)
{
    if (n + numContainers < maxLoad() && n > 0)
    {
        numContainers = n + numContainers;
        return true;
    }
    else
    {
        return false;
    }
}

